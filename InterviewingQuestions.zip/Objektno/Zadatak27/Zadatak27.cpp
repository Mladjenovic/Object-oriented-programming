/*
#include <iostream>
using namespace std;

template<class X, class Z, int Y>
class GEN{

    private:
        X a[Y];
        Z* d;
    public:
        GEN(){
            d = new Z(2);
            int i=0;
            do{
                a[i] = i;
                i++;
            }while(i<Y){
                a[i]=d;
                i++;
            }
        }

        ~GEN(){
            cout<< *d;
            for(int i=0; i<Y; i++)
            cout<< a[i];
        }
};

int main()
{
    GEN<int,int,1> g1,g2(2);
    return 0;
}
*/
//Program ispisuje
