/*
#include <iostream>
using namespace std;

class A{

    public:
        int x,y;
        A(){ x = 1; y = 2;}
        void print(){cout<<y;}
};

void f(A& a){

    a.x++;
    a.y++;
}

int main(){

    A a1, a2;
    f(a1);
    a2=a1;
    f(a1);
    f(a2);
    a1.print();
    a2.print();
    return 0;
}
*/

//Program ispisuje: 44
