/*
#include <iostream>
using namespace std;

class A{

    public:
        A(){cout<<" AKX ";}
        A(int a){cout<<" AK "<<a;}
        ~A(){cout<<" AD ";}
};

class B{

    public:
        B(){cout<<" BKX ";}
        B(int b){cout<<" BK "<<b;}
        ~B(){cout<<" BD ";}
};

class C:public A{

    private:
        B b;
    public:
        C():A(){cout<<" CKX ";}
        C(int c):b(c+1) {cout<<" CK "<<c;}
        ~C(){ cout<<" CD ";}
};

int main(){

    B b;
    C c;
    C c1(2);
    return 0;
}
*/
//Program ispisuje: BKX AKX BKX CKX AKX BK3 CK2 CD BD AD CD BD AD BD
