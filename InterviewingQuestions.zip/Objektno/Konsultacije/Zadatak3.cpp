/*
#include <iostream>
using namespace std;

class A{

    public:
        virtual int oduzimanje() = 0;
        virtual int mnozenje() = 0;
};

class B:public A{
    private:
        int a, b;

    public:
        B(){a=2; b=++a;}
        int sabiranje(){
            return a+b;
        }

        int mnozenje(){
           return a*b;
        }
};

int main(){

    B b;
    b.sabiranje();
    b.mnozenje();
    cout<<b<<endl;
    return 0;
}
*/
//Program ispisuje gresku
