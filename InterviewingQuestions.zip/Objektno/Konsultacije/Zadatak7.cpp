/*
#include <iostream>
using namespace std;

class A{

    private:
        int x,y;
    public:
        A(){x=1;y=2;}
        A(int xx, int yy){x=xx; y=yy;}
        A(const A& a){x=a.x; y=a.y;}
        void ispis(){
            cout<< ++x <<y++;
        }
};


int main(){

    A a, a2(3,4), a3(a2);
    a.ispis();
    a2.ispis();
    a3.ispis();

    return 0;
}
*/
//Program ispisuje: 22 44 44
