/*
#include <iostream>
using namespace std;

class T{

private:
    static int x,y;

public:
    T(){ ++x; y++; }
    ~T(){ x--; --y; }
    void dodaj(int i){
        x+=y;
        y++;
        cout<<x<<y;
    }
    friend ostream& operator<<(ostream &out, const T &t){
        out<<t.y<<t.x;
        return out;
    }
};

int T::x=1;
int T::y=0;

int main(){
    T a;
    a.dodaj(1);
    cout<<a<<endl;
    return 0;

}
*/
//Program ispisuje: 32 23
