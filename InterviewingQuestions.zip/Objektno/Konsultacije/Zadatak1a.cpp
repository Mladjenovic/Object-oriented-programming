/*
#include <iostream>
using namespace std;

int main(){

    int a = 1;
    int b = 1;
    int* pa;
    int* pb;
    pa= &a;
    pb= &a;
    b= ++a;
    cout<< ++(*pa);
    cout<< (*pb)++;
    return 0;
}
*/
//Program ispisuje: 33
