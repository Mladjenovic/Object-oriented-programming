/*
#include <iostream>
using namespace std;

class A{

    public:
        virtual int sabiranje() = 0;
        virtual int mnozenje() = 0;
};

class B:public A{
    private:
        int a, b;

    public:
        B(){a=2; b=++a;}
        int sabiranje(){
            return a+b;
        }

        int mnozenje(){
           return a*b;
        }
        friend ostream& operator<<(ostream &out, const B &a){
            out<<a.a<<a.b;
            return out;
        }
};

int main(){

    B b;
    cout<<b.sabiranje()<<endl;
    cout<<b.mnozenje()<<endl;
    return 0;
}
*/
//Program ispisuje: 69
