/*
#include<iostream>
using namespace std;

int main()
{
	int a=1;
	int b=1;
	int *pa;
	int *pb;

	pa=&a;
	pb=&b;
	b=a++;
	cout<<*pb;
	cout<<++(*pa);
	return 0;
}
*/
//Program ispisuje: 13
