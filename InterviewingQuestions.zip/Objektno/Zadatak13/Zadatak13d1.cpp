/*
#include<iostream>
using namespace std;

int main()
{
	int a, b, c;
	int &rs=a, &rb=b,&rc=c;

    a=1;
    int *p=&rs;
    *p=b;
	b=8;
	c=9;


	cout<<a<<b<<c<<"\n";
	return 0;
}
*/
//Program ispisuje:  268762 89(zasto ove random brojeve...zato sto je b random u trenutku dodoele u liniji 12)
