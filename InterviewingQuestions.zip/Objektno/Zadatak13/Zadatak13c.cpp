/*
#include<iostream>
using namespace std;

int main()
{
	int a, b, c;
	int &rs=a, &rb=b,&rc=c;
	a=1;
    int *p=&rs;
    *p=15;
	b=8;
	c=9;
	cout<<a<<b<<c<<"\n";
	return 0;
}
*/

//Program ispisuje: 1589
