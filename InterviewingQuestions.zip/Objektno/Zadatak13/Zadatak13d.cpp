/*
#include<iostream>
using namespace std;

int main()
{
	int a, b, c;
	int &rs=a, &rb=b,&rc=c;

    a=1;
	b=8;
	c=9;

	int *p=&rs;
    *p=b;
	cout<<a<<b<<c<<"\n";
	return 0;
}

*/
//Program ispisuje:  889
