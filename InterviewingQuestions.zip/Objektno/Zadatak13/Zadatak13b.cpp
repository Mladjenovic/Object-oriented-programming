/*
#include<iostream>
using namespace std;

int main()
{
	int a, b, c;
	int &rs=a, &rb=b,&rc=c;
    int *p=&rb;
    *p=15;
	a=1;
	b=8;
	c=9;
	int *d = &rc;
    *d = a;

	cout<<a<<b<<c<<*d<<"\n";
	return 0;
}
*/
//Program ispisuje: 1811
