/*
#include<iostream>
using namespace std;

class A
{
public:
    int x;
	A(int xx){x=xx;}
	A& operator++()
	{
		x++;
		A temp(++x);
		cout<<x;
		temp.x = ++x;
        cout<<x;
        return *this;
        cout<<x;
	}
	A operator++(int i)
	{
		A temp(x);
		x++;
		cout<<"B";
		return temp;
		cout<<x;
	}
};

int main()
{
	A a(6);
	a++;
	++a;
	return 0;
}
*/
//Program ispisuje: B910 (ne ispise ono sto je iza return temp i return *this)

