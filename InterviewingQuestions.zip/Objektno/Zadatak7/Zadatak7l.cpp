/*
#include<iostream>
using namespace std;

class A
{
	public:
	    A(){cout<<" AK ";}
	   ~A(){cout<<" AD ";}
};

class B:public A
{
	public:
	   B() : A(){cout<<" BK ";}
	   ~B(){cout<<" BD ";}
};

class C:public A
{
    private:
    B b;
	public:
	    C(){cout<<"CK";}
};

int main()
{
	B b;
	C c;
	return 0;
}
*/

//Sta ce program ispisati? AK BK AK AK BK CK BD AD AD BD AD





