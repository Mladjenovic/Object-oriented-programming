/*
#include<iostream>
using namespace std;

class A
{
	public:
	    A(){cout<<" AK ";}
	   ~A(){cout<<" AD ";}

};

class B:public A
{
	public:
	   B() : A(){cout<<" BK ";}
	   ~B(){cout<<" BD ";}
};

class C:public A
{
    private:
    B b;
    A a;
	public:
	    C(){cout<<" CK ";}
	    ~C(){cout<<" CD ";}

};

int main()
{
	B b;
	C c;

	return 0;
}

*/
/*Sta ce program ispisati? AK BK AK AK BK AK CK CD AD BD AD AD BD AD
Ako prava pristupa klasi A stavimo private ili protected
isto ce ispisati kao i sa public, samo ako imamo polja u A,
koja su private onda ne mozemo pristupiti
*/




