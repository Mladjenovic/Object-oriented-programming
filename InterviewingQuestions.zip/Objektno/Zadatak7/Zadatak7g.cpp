/*
#include<iostream>
using namespace std;

class A
{
	public:
	    A(){cout<<" AK ";}
	   ~A(){cout<<" AD ";}
};

class B:public A
{
	public:
	   B() : A(){cout<<" BK ";}
};

class C:public A
{
    private:
    B b;

	public:
	   C(){cout<<" CK ";}
	   ~C(){cout<<" CD ";}
};

int main()
{
	B b;
	C c;
	return 0;
}
*/

//Sta ce program ispisati? AK BK AK AK BK CK CD AD AD AD


