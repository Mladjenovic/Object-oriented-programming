/*
#include<iostream>
using namespace std;

class A
{
	public:
	    A(){cout<<"AK";}
	   ~A(){cout<<" AD ";}
};

class B: public A
{
	public:
	   B():A(){cout<<" BK ";}
	   ~B(){cout<<" BD ";}
};

class C
{
	private:
	   B b;
	public:
	   C(){cout<<" CK ";}
	   ~C(){cout<<" CD ";}
};

int main()
{
	B b;
	C c;
	return 0;
}

*/
//Sta ce program ispisati? AK BK AK BK CK CD BD AD BD AD

