/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){}
	   ~A(){cout<<x<<y;}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<<a.x<<a.y;
		return out;
	   }
};

void fun2(A a){a.x=3; a.y=2;}
void fun1(A& a){a.x=5; a.y=1;}

int main()
{
	A a;
	cout<<a;
	fun2(a);
	cout<<a;
	return 0;
}
*/
//Program ispisuje: random_brojeve 32 random_brojeve random_brojeve
