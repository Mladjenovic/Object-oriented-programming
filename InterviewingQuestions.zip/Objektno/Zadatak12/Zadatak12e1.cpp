/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){x=1; y=2;}
	   ~A(){}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<<a.y<<a.x;
		return out;
	   }
};

void fun2(A a){a.x=2; a.y=2;}

int main()
{
	A a;
	fun2(a);
	cout<<a;

	return 0;

}
*/
//Sta ispusije?  21(ispise prethodne vrijednosti, ne vrijednosti kopije)
