/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){x=1; y=2;}
	   ~A(){cout<<x<<y;}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<<a.x<<a.y;
		return out;
	   }
};

void fun2(A a){a.x=3; a.y=2;}
void fun1(A& a){a.x=5; a.y=1;}

int main()
{
	A a;
	fun2(a);
	cout<<a;
	return 0;
}
*/
//Program ispisuje: 32 12 12
