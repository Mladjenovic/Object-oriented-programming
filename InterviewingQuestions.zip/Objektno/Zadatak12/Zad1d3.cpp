/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){}
	   ~A(){}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<<a.y<<a.x;
		return out;
	   }
};

void fun2(A a){a.x=6; a.y=2;}
void fun1(A& a){a.x=5; a.y=1;}

int main()
{
	A a;
	cout<<a;
	fun1(a);
	cout<<a;
	fun2(a);
	cout<<a;
	return 0;
}
*/
//Program ispisuje: random_brojeve 15 15
