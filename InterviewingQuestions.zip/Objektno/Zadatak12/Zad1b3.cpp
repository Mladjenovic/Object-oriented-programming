/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){}
	   ~A(){cout<< x << y ;}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<< a.y << a.x ;
		return out;
	   }
};

void fun2(A a){a.x=14; a.y=4;}
void fun1(A& a){a.x=2; a.y=5;}

int main()
{
	A a;
	cout<<a;
	fun1(a);
	cout<<a;
	fun2(a);
	cout<<a;
	return 0;
}

*/
//Sta program ispisuje? random_brojeve 52 144 52 25
