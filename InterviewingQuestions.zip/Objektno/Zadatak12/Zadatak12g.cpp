/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){}
	   ~A(){cout<<x<<y;}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<<a.x<<a.y;
		return out;
	   }
};

void fun1(A& a){a.x=1; a.y=1;}

int main()
{
	A a;
	fun1(a);
	cout<<a;
	return 0;
}
*/
//Sta ispisuje? 1111
