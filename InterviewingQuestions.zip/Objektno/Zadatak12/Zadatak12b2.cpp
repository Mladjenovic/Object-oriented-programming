/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){x=1; y=2;}
	   ~A(){cout<<y<<x;}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<<a.x<<a.y;
		return out;
	   }
};

void fun1(A& a){a.x=1; a.y=1;}

int main()
{
	A a;
	fun1(a);

	return 0;

}
*/
//Sta program ispisuje? 11
