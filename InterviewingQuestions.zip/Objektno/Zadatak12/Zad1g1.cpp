/*
#include<iostream>
using namespace std;
class A
{
	public:
	   int x, y;
	public:
	   A(){x=1; y=2;}
	   ~A(){cout<<x<<y;}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
	   	out<<a.y<<a.x;
		return out;
	   }
};

void fun2(A a){a.x=3; a.y=2;}
void fun1(A& a){a.x=5; a.y=1;}

int main()
{
	A a;
	fun2(a);
	cout<<a;
	fun1(a);
	return 0;
}
*/
//program ispisuje:  32 21 51 (unistis kopiju, ispises staru vrijednost, unistis stvarnu vrijednost)
