/*
#include <iostream>

using namespace std;
class A
{
public:
    A() {cout<<"A1";}
    ~A() {cout<<"A2";}
};
class B
{
public:
    B() {cout<<"B1";}
    ~B() {cout<<"B2";}
};
int main()
{
   A a;
   B b;
   return 0;
}
*/
//Sta ce biti ispisano? A1 B1 B2 A2
