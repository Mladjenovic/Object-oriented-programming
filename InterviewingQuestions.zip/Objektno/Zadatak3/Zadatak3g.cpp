/*
#include <iostream>

using namespace std;
class A
{
public:
    A(){}
    ~A() {cout<<"A2";}
};
class B:public A
{
public:
    B(){}
    ~B() {cout<<"B2";}
};
int main()
{
   A a;
   B b;
   return 0;
}

*/
//Sta ce biti ispisano? B2 A2 A2
