/*
#include <iostream>

using namespace std;
class A: public B
{
public:
    A() {cout<<"A1";}
    ~A() {cout<<"A2";}
};
class B
{
public:
    B() {cout<<"B1";}
    ~B() {cout<<"B2";}
};
int main()
{
   A a;
   B b;
   return 0;
}
*/
//Sta ce biti ispisano? Greska jer program ne zna sta je B u 4. redu
