/*
#include <iostream>

using namespace std;
class A
{
public:
    A() {cout<<"A1";}
    ~A() {}
};
class B
{
public:
    B() {cout<<"B1";}
    ~B() {}
};
int main()
{
   A a;
   B b;
   return 0;
}
*/

//Sta ce biti ispisano A1 B1
