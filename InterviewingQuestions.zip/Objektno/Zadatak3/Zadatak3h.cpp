/*
#include <iostream>

using namespace std;
class A
{
public:
    A();
    ~A() {cout<<"A2";}
};
class B
{
public:
    B();
    ~B() {cout<<"B2";}
};
int main()
{
   A a;
   B b;
   return 0;
}
*/

//Sta ce biti ispisano? Greska kod konstruktora A(); i B();
// Treba da stoji A() {} i B() {} da bi bilo ispravno
