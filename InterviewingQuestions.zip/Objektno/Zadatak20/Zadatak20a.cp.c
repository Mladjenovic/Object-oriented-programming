#include<iostream>
using namespace std;

class A
{
	public:
	   int a;
       int b;
	   A(){a=1; b=3;}
	   A(int aa, int bb){a=aa; b=bb;}
	   int getA() const{return a;}
	   int getB() const{return b;}
};


int main()
{
	A a(3,1), b;
	a.a += b.b;
	a.b += b.a;
	b.a += a.b;
	b.b += a.a;
	cout<<a.a<<a.b<<b.a<<b.b;
}


//Program ispisuje: 6239
