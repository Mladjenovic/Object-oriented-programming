/*
#include <iostream>
using namespace std;

class A
{
	public:
	   int a;
	   static int b;
	   A(){a=1;}
	   A(int aa){a=++b; a+=aa;}
	   int getA() const{return a;}
	   int getB() const{return b;}

};

int A::b=2;

int main()
{
	A a(3), b;
	a.a += b.b;
	a.b += b.a;
	b.a += a.b;
	b.b += a.a;
	cout<<a.a<<a.b<<b.a<<b.b;
}
*/
//Program ispisuje 9 13 5 13
//PAZI NA: 1.static int kad si ga promjenila u konstruktoru A a(3) on ti je ostao promjenjen, tj. nije vise 2, nego je 3.

