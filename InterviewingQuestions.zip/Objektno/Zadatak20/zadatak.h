#ifndef ZADATAK_H_INCLUDED
#define ZADATAK_H_INCLUDED

#include <iostream>

enum nesto{a, b=2, c};

int main(){


    cout


}

#endif // ZADATAK_H_INCLUDED
