/*
#include<iostream>
using namespace std;

class A
{
	public:
	   static int a;
       int b;
	   A(){b=3;}
	   A(int bb){b=bb;}
	   int getA() const{return a;}
	   int getB() const{return b;}
};

int A::a=0;

int main()
{
	A a(1), b;
	a.a += b.b;
	a.b += b.a;
	b.a += a.b;
	b.b += a.a;
	cout<<a.a<<a.b<<b.a<<b.b;
}
*/

//Program ispise: 74710
