/*
#include<iostream>
using namespace std;

class A
{
	public:
	   int a;
	   static int b;
	   A(){a=1;}
	   A(int aa){a=aa;}
	   int getA() const{return a;}
	   int getB() const{return b;}
};

int A::b=2;

int main()
{
	A a(3), b;
	a.a += b.b;
	a.b += b.a;
	b.a += a.b;
	b.b += a.a;
	cout<<a.a<<a.b<<b.a<<b.b;
}
*/

//Program ispisuje: 5848(pazi se static inta, jer kad promjenis neko polje sto ima static int, mora se i drugo promjeniti na istu vrjednost(samo ako je static))
