
#include<iostream>
using namespace std;

class A
{
	private:
	   int x, y;
	public:
	   A(){x=5; y=5;}
	   void petlja(int n){for(int i=0; i<n; i++) x+=y; y+=x;}
	   friend ostream& operator<<(ostream &out, const A& a)
	   {
		out<<a.x<<a.y<<endl;
		return out;
	   }
};

int main()
{
	A a;
	a.petlja(3);
	cout<<a;
	return 0;
}

//Sta program ispisuje? 2025


