/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual void f(){cout<<"A";}
};

class B : public A
{
	public:
	   void f(){cout<<"B";}
};

int main()
{
	A a;
	B b;
	A* pa;
	B* pb;
	pa=&b;
	pb=&a;
	a.f();
	b.f();
	pa->f();
	pb->f();
	return 0;
}
*/

//Program se nece izvrsiti jer cemo dobiti upozorenje o gresci(ne mozemo pb = &a jer a je iz roditeljske klase, a b iz potomka, obrnuto moze)
