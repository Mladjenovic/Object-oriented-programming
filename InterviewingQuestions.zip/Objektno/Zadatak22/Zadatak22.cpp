/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual void f(){cout<<"A";}
};

class B : public A
{
	public:
	   void f(){cout<<"B";}
};

int main()
{
	A a;
	B b;
	A* pa;
	B* pb;
	pa=&a;
	pb=&b;
	a.f();
	b.f();
	pa->f();
	pb->f();
	return 0;
}
*/
//Program ispisuje: ABAB
