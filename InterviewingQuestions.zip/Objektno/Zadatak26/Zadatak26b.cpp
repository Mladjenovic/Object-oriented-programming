/*
#include <iostream>
using namespace std;

class A{

    public:
        virtual void otvori()=0;
        virtual void zatvori()=0;
};

class B{
    private:
        char s;
    public:
        ~B(){ s = 'z'; cout<<s;}
        void otvori(){
            if(s!='o')
                s = 'o';
        }
       void zatvori(){
        if(s!='z')
            s='z';
    }
        char getState() const {return s;}
};

int main()
{
    B b;
    b.otvori();
    cout<<b.getState();
    b.zatvori();
    cout<<b.getState();
}
*/
//ispis ozz;
