

#include<iostream>
using namespace std;

enum Stanje{ON, OFF, ONN=4, ONNN};

class Masina
{
	private:
	   Stanje stanje;
	public:
	   Masina(){stanje=OFF;}
	   Masina(Stanje s){stanje=s;}
	   Masina(const Masina &m){stanje=m.stanje;}
	   ~Masina(){stanje=OFF;}
	   friend ostream& operator<<(ostream &out, const Masina &m)
	   {
		out<<m.stanje;
		return out;
	   }
};

int main()
{
	Masina m1, m3(ON), m2(m3), m4(ONN), m5(ONNN);
	cout<<m1<<m2<<m3<<m4<<m5<<endl;
	return 0;
}

//Sta ce program ispisati? 10045


/*
    7.zadatak:

Koje su tacne recenice:
    1. Postoje pokazivaci na reference.
    2. Ne postoje pokazivaci na reference.
    3. Referenca je alternativno ime za neki podatak.
    4. Postoje nizovi referenci.

        Odgovor: 2. i 3.



    8.zadatak:

(Java)Koje su tacne recenice:
    1. Java podrzava direktno visestruko implementiranje sadrzaja interfejsa.
    2. Java ne podrzava direktno visestruko implementiranje interfejsa.
    3. Java podrzava direktno visestruko nasledjivanje sadrzaja klasa(natklasa).
    4. Java ne podrzava direktno visestruko nasledjivanje sadrzaja klasa(natklasa).

        Odgovor: 1. i 4.
*/
