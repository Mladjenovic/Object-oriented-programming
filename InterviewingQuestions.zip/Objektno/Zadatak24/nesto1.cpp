/*

#include <iostream>
using namespace std;

class A{

public:
    void p(){ cout<<"BogOtac";}
};

class B:public A{

public:
    void p(){cout<<"BozjiSin";}
};

void f(A& a, B& b){ a.p(), b.p();}

int main(){

    B b;
    f(b,b);
    b.p();
    return 0;
}
*/
//Program ispisuje: BogOtac BozijiSin BozijiSin

