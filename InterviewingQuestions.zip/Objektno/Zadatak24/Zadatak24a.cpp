/*
#include <iostream>
using namespace std;

class A{

public:
    virtual void f(){ cout<<"BogOtac";}
};

class B:public A{

public:
    void f(){cout<<"BozjiSin";}
};


int main(){

    A a;
    B b;
    A* pa;
    B* pb;
    pa = &b;
    pb = &b;
    a.f();
    b.f();
    pa->f();
    pb->f();
    return 0;
}
*/

//Program ispisuje: BogOtac BozjiSin BozjiSin BozjiSin

