/*
#include<iostream>
using namespace std;

class A
{
	private:
	   int a, b;
	public:
       A(){a=1; b=2;}
	   A(int aa=1, int bb=2){a=aa; b=bb;}
	   A(const A& aa){a=aa.a; b=aa.b;}
	   void ispis()
	   {cout<<++a<<b++;}
};

int main()
{
	A a, a2(3,4), a3(a2);
	a.ispis();
	a1.ispis();
	a3.ispis();
}
*/

/*Sta ce ispisati program? Greska: 1. u mainu imam objekte a,a2,a3, a ispisujem a1 koje nemam.
                                   2. Imamo konstruktor bez parametara, pa onda konstruktor sa parametrima i bez u jednom-to ne moze.
                                   Da je samo pisalo A(int aa=1, int bb=2){a=aa; b=bb;} moglo bi

*/
