/*
#include<iostream>
using namespace std;

class A
{
	private:
	   int a, b;
	public:
       A(){a=1; b=++a;}
	   void ispis()
	   {cout<<++a<<b++;}
};

int main()
{
	A a, a3(a);
	a.ispis();
	a3.ispis();
}

*/
//Sta ispisuje? 3232
