/*
#include<iostream>
using namespace std;

class A
{
	private:
	   int a, b;
	public:
       A(int aa=1, int bb=2){a=aa+bb; b=aa-bb;}
	   A(const A& aa){a=aa.a; b=aa.b;}
	   void ispis()
	   {cout<<++a<<b++;}
};

int main()
{
	A a, a3(a);
	a.ispis();
	a3.ispis();
}
*/

//Sta ispisuje? 4 -1 4 -1


