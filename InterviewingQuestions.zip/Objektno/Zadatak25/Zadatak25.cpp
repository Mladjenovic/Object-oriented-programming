/*
#include <iostream>
using namespace std;

class A{

    private:
        int x;
        int y;

        A(int pom){x=pom++; y=++pom;}
        void print(){cout<<x<<y;}

};

void inc(A& a){
    a.x++;
    a.y++;
}

int main(){

    A a1(5);
    inc(a1);
    a1.print();
    return 0;
}
*/
//Program ispisuje gresku jer je sve u klasi A private
