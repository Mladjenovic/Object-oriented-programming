
#include <iostream>
using namespace std;

class A{

    public:
        int x;
        int y;

        A(int pom){x=pom++; y=++pom;}
        ~A(){cout<<x<<y;}
        void print(){cout<<x<<y;}



};

void inc(A a){
    a.x++;
    a.y++;
}

int main(){

    A a1(5);
    inc(a1);
    a1.print();
    return 0;
}

//Program ispisuje 685757
