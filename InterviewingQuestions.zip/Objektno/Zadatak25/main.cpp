/*
#include <iostream>
using namespace std;

class A{

    public:
        void show(){cout<<"C";}
};

class B:public A{

    public:
        virtual void show(){cout<<"B";}
};

class C: public B{

    public:
        void show(){cout<<"A";}
};

int main()
{

    A a;
    B b;
    C c;
    a.show();
    b.show();
    c.show();

    return 0;
}
*/
//Program ispise: CBA
