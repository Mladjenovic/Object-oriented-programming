/*
#include<iostream>
using namespace std;

void c(int &r){r=1;}
void c(int *r){*r=2;}

int main()
{
	int a=4;
	c(a);
	cout<<a;
	c(a);
	cout<<a;
	return 0;
}
*/
/*  BITNO:
    Ako u f-ji imas nesto sto dajes po referenci ili pokayivacu, ti mijenjas vrijednost a=4 pri pozivu f-je c(a=1 ili a=2)
    Ako u f-ji imas nesto sto dajes po vrijednosti, ti ne mijenjas vrijednost a=4, vec ti se ta vrijednost ispisuje.
*/
