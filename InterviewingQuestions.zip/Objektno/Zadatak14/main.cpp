
/*
#include<iostream>
using namespace std;

void c(int &r){r=1;}
void e(int r){r=2;}
void c(int *p){*p=3;}

int main()
{
	int a=4;
	c(a);
	cout<<a;
	c(a);
	cout<<a;
	return 0;
}
*/
//Program ispisuje: 11
/*

    Date su recenice:
1. Konstruktor je metoda koja kreira objekat.
2. Mogu se preklopiti operatori samo za klasne tipove.
3. Operatori se preklapaju putem operatorskih metoda.
4. Podrazumevani konstruktor je metoda koja samo kreira objekat.

*/
