/*
#include<iostream>
using namespace std;

void c(int &r){r=1;}
void c(int r){r=2;}

int main()
{
	int a=4;
	c(a);
	cout<<a;
	c(a);
	cout<<a;
	return 0;
} */

//Program ispisuje: Greska, jer ne mozemo imati isti naziv f-je
// kad proslijedjujemo referencu i vrijednost:
/*
1.  void c(int &r){r=1;}
    void c(int r){r=2;}   ovo ne moze

2.  void c(int r){r=2;}
    void c(int *p){*p=3;}  ovo moze

3.  void c(int *p){*p=3;}
    void c(int &r){r=1;}  ovo moze

*/
