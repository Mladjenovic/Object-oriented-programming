/*
#include<iostream>
using namespace std;

void c(int r){r=1;}
void c(int *r){*r=2;}

int main()
{
	int a=4;
	c(a);
	cout<<a;
	c(a);
	cout<<a;
	return 0;
}
*/
//Program ispisuje: 44
