#include <iostream>
using namespace std;
class A{

public:
    static int broj;
    A(){broj++;}
    ~A(){++broj;}

    int& getValue()const{
     return broj;
    }

    friend ostream& operator<<(ostream& out, const A& a){
        out<<a.broj;
        return out;
    }
};

int A::broj=0;

void f1(A obj){
    A::broj=0;
}

void f2(A& obj){
    A::broj=5;
}

int main()
{
    A a1;
    cout<<a1.getValue();
    f2(a1);
    cout<< a1.getValue();
    f1(a1);
     cout<<a1.getValue();
    return 0;
}
