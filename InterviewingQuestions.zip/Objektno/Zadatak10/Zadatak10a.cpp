/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual int oduzimanje()=0;
	   virtual int sabiranje()=0;
};

class B : public A
{
	private:
	   int a, b;
	public:
	   B(){a=2; b=++a;}
	   int oduzimanje(){return a-b;}
	   int sabiranje(){return a+b;}
};

int main()
{
	B b;
	cout<<b.oduzimanje()<<b.sabiranje();
}
*/
//Sta ce program ispisati? 06



/*
    (Java)Ispravni iskazi su:
    1. int[] n1=new int[];
    2. int[][] n2=new int[3][3];//int n2[] [] = new int [3][3]
    3. int[3][3] n3=new int[][];
    4. int[3][] n4=new int[][3];
    5. int[][3] n5=new int[3][];

        Odgovor: samo 2.




*/
