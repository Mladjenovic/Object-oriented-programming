/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual int oduzimanje(){return 0;}
	   virtual int sabiranje()=0;
};

class B : public A
{
	private:
	   int a, b;
	public:
	   B(){a=2; b=++a;}
	   int sabiranje(){return a+b;}
	   int mnozenje() {return a*b;}
};

int main()
{
	B b;
	cout<<b.oduzimanje()<<b.sabiranje()<<b.mnozenje();
}

*/

//Program ispisuje 069
