/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual int oduzimanje()=0;
	   virtual int sabiranje()=0;
};

class B : public A
{
	private:
	   int a, b;
	public:
	   B(){a=2; b=++a;}
	   int oduzimanje(){return a-b;}
	   int mnozenje(){return a*b;}
};

int main()
{
	B b;
	cout<<b.oduzimanje()<<b.mnozenje();
}
*/
//Sta ce program ispisati? Greska jer kad imamo virutal f-ja = 0; to znaci da ta f-ja mora biti i u naslijedjenoj klasi
