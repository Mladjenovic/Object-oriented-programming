/*
#include<iostream>
using namespace std;

class K {
    private:
        int x,y;
    public:
        K() {x=2;y=9;}
        void f() {
        for(int i=0;i<10;i++)
            x++;
            y++;
            cout<<x<<y<<endl;
    };
int main()
{
   K k;
   k.f();
   return 0;
}
*/

//Sta ce program ispisati? Greska jer nema zatvorene zagrade kod void f()
