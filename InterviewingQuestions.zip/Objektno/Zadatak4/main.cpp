/*
#include <iostream>

using namespace std;
class C
{
public:
    virtual void f() {cout<<"C";}
};
class D:public C
{
public:
        void f() {cout<<"D";}
};
int main()
{
   C c;
   D d;
   c.f();
   d.f();
   C *p;
   p=&d;
   p->f();

   return 0;
}
*/
/*Sta ce biti ispisano? sa virtual - CDD
                        bez virtual - CDC
    kad probas sa private ili protected da naslijedis klasu C, moras paziti:

    C *p;                       C *p;
    p=&d; ovo ne moze           p = &c;  ovo moze
    p->f();                     p->f();
*/

/* 5.zadatak:

    1.Konstruktr sluzi da napravi objekat.
	2.Destruktor se poziva automatski.
	3.Kompozicija je veza izmedju klasa.
	4.Public clanovima se moze pristupiti iz unutrasnjosti klase.
	5.Apstraktna klasa je klasa koja sadrzi bar jednu apstraktnu metodu.
 Koji iskazi su tacni?  (Svi iskazi su tacni)
============================================================================




*/
