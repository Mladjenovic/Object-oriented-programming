/*
#include <iostream>

using namespace std;
class C
{
public:
    C(){cout<<"C1";}
    virtual void f() {cout<<"C";}
    ~C(){cout<<"C2";}
};
class D:public C
{
public:
        D(){cout<<"D1";}
        void f() {cout<<"D";}
        ~D(){cout<<"D2";}
};
int main()
{
   D d;
   d.f();
   C *p;
   p=&d;
   p->f();

   return 0;
}
*/
/*Sta ce biti ispisano? sa virtual - C1D1DDD2C2
                        bez virtual - C1D1DCD2C2

*/
