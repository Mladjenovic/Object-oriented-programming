/*
#include <iostream>

using namespace std;
class C
{
public:
    virtual void f() {cout<<"C";}
};
class D
{
public:
        void f() {cout<<"D";}
};
int main()
{
   C c;
   D d;
   c.f();
   d.f();
   C *p;
   p = &d;
   p->f();

   return 0;
}
*/
//Sta ce biti ispisano? Greska u liniji 21 klasa D ne naslijedjuje klasu C(i sa virtual i bez)
