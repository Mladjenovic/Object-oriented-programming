/*
#include <iostream>

using namespace std;
class C
{
public:
    C(){cout<<"C1";}
     virtual void f() {cout<<"C";}
    ~C(){cout<<"C2";}
};
class D:public C
{
public:
        D(){cout<<"D1";}
        void f() {cout<<"D";}
        ~D(){cout<<"D2";}
};
int main()
{
   C c;
   c.f();
   C *p;
   p=&c;
   p->f();

   return 0;
}
*/
/*Sta ce biti ispisano? sa virtual - C1CCC2
                        bez virtual - C1CCC2

*/
