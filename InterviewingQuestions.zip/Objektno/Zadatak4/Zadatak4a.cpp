/*
#include <iostream>

using namespace std;
class C
{
public:
    virtual void f() {cout<<"C";}
};
class D:public C
{
public:
        void f() {cout<<"D";}
};
int main()
{
   C c;
   D d;
   c.f();
   d.f();
   C *p;
   p=&c;
   p->f();

   return 0;
}
*/
/*Sta ce biti ispisano? sa virtual- CDC
                        bez virtual - CDC
*/
