/*
#include <iostream>

using namespace std;
class C
{
public:
    C(){cout<<"C1";}
    virtual void f() {cout<<"C";}
};
class D:public C
{
public:
        D(){cout<<"D1";}
        void f() {cout<<"D";}
};
int main()
{
   C c;
   D d;
   c.f();
   d.f();
   C *p;
   p=&d;
   p->f();

   return 0;
}
*/
/*Sta ce biti ispisano? sa virtual - C1C1D1CDD
                        bez virtual - C1C1D1CDC
*/
