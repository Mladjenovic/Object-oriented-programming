/*
#include<iostream>
using namespace std;

class A
{
	protected:
	   int x, y;
	public:
	   A(int xx=1, int yy=1) : x(xx), y(yy){}
	   int pomnozi(){return x*y;}
	   int saberi(){return x+y;}
};

class B : public A
{
	private:
	   int z;
	public:
	   B(int xx=1, int yy=2, int zz=3) : z(zz){}
	   int pomnozi(){return x*y*z;}
};

int main()
{
	B b1, b2(1,2,3);
	cout<<b1.saberi()<<b2.saberi();
	return 0;
}
*/

//Program ispisuje: 22
/*
Provjeri prvo privatnost svih polja i metoda. Ako su public mogu se svugjd epojavljivati,
ako su protected mogu se u naslijedjenim klasama, ali ne i u mainu, a ako su private, mogu se
pojaviti smo u toj klasi.
Onda dobro pazi na metode i konstruktore. Ako imas konstruktor klase B koja naslijedjuje A onda ides u taj konsturktor od A,
a metode ako imaju u B onda te pozivas, a ako nemaju onda pozivas one iz A, gdje ti je z=0, jer ga nema u toj klasi A.
*/
