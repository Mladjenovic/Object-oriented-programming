/*
#include<iostream>
using namespace std;

class A
{
	protected:
	   int x, y;
	public:
	   A(int xx=1, int yy=1) : x(xx), y(yy){}
	   int pomnozi(){return x*y;}
	   int saberi(){return x+y;}
};

class B : public A
{
	private:
	   int z;
	public:
	   B(int xx=1, int yy=2, int zz=3) : z(zz){}
	   int pomnozi(){return x*y*z;}
};

int main()
{
    A a1, a2(5,3);
	B b1, b2(1,2,3);
	cout<<a1.saberi()<<a2.pomnozi()<<endl;
	cout<<b1.pomnozi()<<b2.saberi();
	return 0;
}
*/
//Program ispisuje: 21532
