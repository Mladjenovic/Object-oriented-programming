/*
#include<iostream>
using namespace std;

class A
{
	public:
       A(){cout<<"B1";}
	   void p(){cout<<"B";}
};

class B : public A
{
	public:
	   B(){cout<<"A1";}
	   void p(){cout<<"A";}
};

void f(B& ra){ra.p();}

int main()
{
    A a;
	B b;
	b.p();
	a.p();
	f(b);
	f(a);
	return 0;
}
*/
//Program ispisuje: B1B1A1ABA I GRESKAAAAAA U 27.LINIJI KODA
