/*
#include<iostream>
using namespace std;

class A
{
	public:
    void p(){cout<<"B";}
};

class B
{
	public:
	   void p(){cout<<"A";}
};

void f(A& ra){ra.p();}

int main()
{
    A a;
	B b;
	a.p();
	b.p();
	f(b);

	return 0;
}
*/
//Program ispisuje: GRESKA jer u f-ji f on ocekuje nesto tipa A a ti mu dajes nesto tipa B
