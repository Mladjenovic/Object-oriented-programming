/*
#include<iostream>
using namespace std;

class A
{
	public:
    void p(){cout<<"B";}
};

class B
{
	public:
	   void p(){cout<<"A";}
};

void f(A& ra){ra.p();}

int main()
{
    A a;
	B b;
	a.p();
	b.p();
	f(a);

	return 0;
}
*/
//Program ispisuje: BAB
