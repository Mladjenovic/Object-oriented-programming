/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual void p(){cout<<"B";}
};

class B:public A
{
	public:
	   void p(){cout<<"A";}
};

void f(A& ra){ra.p();}

int main()
{
    A a;
	B b;
	a.p();
	b.p();
	f(a);
	f(b);
	return 0;
}
*/
//Program ce ispisati:  BABA
