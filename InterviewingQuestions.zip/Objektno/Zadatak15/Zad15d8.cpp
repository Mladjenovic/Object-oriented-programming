/*
#include<iostream>
using namespace std;

class A
{
	public:
       A(){cout<<"B1";}
       ~A(){cout<<"B2";}
	   virtual void p(){cout<<"B";}
};

class B
{
	public:
	   B(){cout<<"A1";}
	   ~B(){cout<<"A2";}
	   void p(){cout<<"A";}
};

void f(B& ra){ra.p();}

int main()
{
    A a;
	B b;
	b.p();
	a.p();
	f(b);
	f(a);
	return 0;
}
*/

//Program ispisuje: greska
