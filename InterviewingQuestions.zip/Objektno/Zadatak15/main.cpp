/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual void p(){cout<<"B";}
};

class B : public A
{
	public:
	   void p(){cout<<"A";}
};

void f(A& a){ra.p();}//void f(A& ra){ra.p()}

int main()
{
	B b;
	b.p();
	f(b);
	return 0;
}
*/
/*Program ispisuje  gresku(ra was not declared in this scope) jer
 ti f-ji f das nesto po referenci(a) a u tijelu f-je pises ra, sto ne moze

 Da je islo:
  1.void f(A& ra) {ra.p();}
  2.void f(A& a){a.p();}
    moglo bi oboje
*/

/*
    16.zadatak:
    Koje su tacne recenice:
1. C++ program mora da ima tacno jednu main metodu.
2. U C++u postoji obrada izuzetaka (try-catch blok).
3. U C++u postoje interfejsi.
4. U C++u svaka napisana klasa mora biti u zasebnom fajlu.

@@@Odgovor: ???

*/
