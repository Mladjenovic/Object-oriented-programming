/*
#include<iostream>
using namespace std;

class A
{
	public:
	   void p(){cout<<"B";}
};

class B : public A
{
	public:
	   void p(){cout<<"A";}
};

void f(B& ra){ra.p();}

int main()
{
	A a;
	a.p();
    f(a);
	return 0;
}
*/
//Program ispisuje: Greska jer u f-ji f on ocekuje nesto tipa B a ti mu dajes A
