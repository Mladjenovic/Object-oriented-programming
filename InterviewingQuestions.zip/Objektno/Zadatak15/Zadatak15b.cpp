/*
#include<iostream>
using namespace std;

class A
{
	public:
	   virtual void p(){cout<<"B";}
};

class B{
	public:
	   void p(){cout<<"A";}
};

void f(A& ra){ra.p();}

int main()
{
	B b;
	b.p();
	f(b);
	return 0;
}
*/
//Program ce ispisati: Greska u 21. liniji koda(u f-ji void f(A& ra) on ocekuje nesto tipa A,
                       // a ti mu dajes B, to ne moze jer B ne naslijedjuje A)
