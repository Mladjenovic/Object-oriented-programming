/*
#include<iostream>
using namespace std;

class A
{
	public:
       A(){cout<<"B1";}
	   virtual void p(){cout<<"B";}
};

class B
{
	public:
	   B(){cout<<"A1";}
	   void p(){cout<<"A";}
};

void f(A& ra){ra.p();}

int main()
{
	B b;
	b.p();
	f(b);
	return 0;
}
*/
//Program ispisuje: A1A i onda greska u f-ji void f ocekujes A, ja ti dajem B
