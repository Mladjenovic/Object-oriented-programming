/*
#include <iostream>
using namespace std;
void f(int &r)
{
    r=5;
}
void f(int *p)
{
    *p=9;
}

int main()
{
   int a=3;
   cout<<a;
   f(a); //pozivanje reference
   cout<<a;
   f(&a); // moras adresu zbog pokazivaca(da nema adrese 355) pozivanje pokazivaca
   cout<<a;
   return 0;
}
*/
//Sta ce program ispisati? 359
