/*
#include <iostream>

using namespace std;

void f(int r){

    r = 13;
}

void f(int *p)
{
    *p=9;
}
int main()
{
   int a=3;
   cout<<a;
   f(a);
   cout<<a;
   f(&a);
   cout<<a;
   return 0;
}
/*
/*
    Sta ce biti ispisano?
    339
    Pokazivac i referenca mijenjaju vrijednost promjenljve,
    a obicna int(double...) ne mijenja, vec ostaje vrijednost koju
    smo mi zadali, u ovom slucaju a=3(u mainu).
*/


