/*
#include <iostream>

using namespace std;
void f(int &r)
{
    r=5;
}
void f(int r){

    r = 13;
}

int main()
{
   int a=3;
   cout<<a;
   f(a);
   cout<<a;
   f(a);
   cout<<a;
   return 0;
}*/
/* Sta ce program ispisati? Gresku, jer imamo dvije funkcije istog imena,
     program ne zna koju da pozove. Da smo imali samo
    void f(int r) i void f(int *r) moglo bi,
    void f(int &r) i void f(int *r) moglo bi,
    void f(int r) i void f(int &r) NE MOZE!
    */
