/*
#include<iostream>
using namespace std;

class A
{
	protected:
	   int a;
	public:
	   A(){a=0;}
	   A(int aa) : a(aa){}
	   int getA(){return a;}
};

class B : protected A
{
	protected:
	   int b;
	public:
	   B(){b=1;}
	   B(int bb) : b(bb){}
	   int getB(){return b;}
};

class C : public B
{
	private:
	   int c;
	public:
	   C() {c=2;}
	   C(int cc) {a=1; c=cc;}
	   void print(){cout<<a<< " " <<c<< "   " <<b<<"  "<<endl;}
};

int main()
{
	C c1(2), c2;
	c1.print();
	c2.print();
}
*/
//ispis: 1 2 1 0 2 1
