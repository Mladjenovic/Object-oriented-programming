/*
#include<iostream>
using namespace std;

class A
{
	protected:
	   int a;
	public:
	   A(){a=0;}
	   A(int aa) : a(aa){}
	   int getA(){return a;}
};

class B : public A
{
	private:
	   int b;
	public:
	   B(){b=1;}
	   B(int bb) : b(bb){}
	   int getB(){return b;}
};

class C : public B
{
	private:
	   int a;
	   int b;
	   int c;
	public:
	   C() {c=2;}
	   C(int cc) {a=1; c=cc;}
	   void print(){cout<<a<< " " <<c<< "   " <<b<<"  "<<endl;}
};

int main()
{
	C c1(2), c2;
	c1.print();
	c2.print();
}
*/

//ispis: 1 2 random_broj random_broj 2 random_broj(on ne uzima ono a iz klase A, vec ovo novo sto si napravila a ne znas koliko ti je, kao i b)
