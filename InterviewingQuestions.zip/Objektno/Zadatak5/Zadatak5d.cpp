/*
#include<iostream>
using namespace std;
class T
{
	public:
	   static int x, y;
	public:
	   T(){++x; y++;}
	   ~T(){x--; --y;}
	   void dodaj(int i){cout << x << y;}
	   friend ostream& operator<<(ostream & out, const T& t)
	   {
	   	out<<t.x<<t.y;
		return out;
	   }
};

int T::x = 0;
int T::y = 0;

void radi(T t){
    t.x++;
    --t.y;
}

int main()
{
    T a;
	a.dodaj(5);
	radi(a);
	cout<<a<<endl;
	return 0;
}
*/
//Program ispisuje 111-1 (zbog destruktora, jer smo imali f-ju void radi(T t) koja radi sa kopijom pa se mora unistiti)
