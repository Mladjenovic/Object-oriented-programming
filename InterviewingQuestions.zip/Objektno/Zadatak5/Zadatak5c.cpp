/*
#include<iostream>
using namespace std;
class T
{
	private:
	   static int x, y;
	public:
	   T(){++x; y++;}
	   ~T(){x--; --y;}
	   void dodaj(int i){cout << x << y;}
	   void radi(){ x+=y; y-=x; }
	   friend ostream& operator<<(ostream & out, const T& t)
	   {
	   	out<<t.x<<t.y;
		return out;
	   }
};

int T::x = 0;
int T::y = 0;

int main()
{
    T a;
	a.dodaj(5);
	a.radi();
	cout<<a<<endl;
	return 0;
}
*/
//Program ispisuje 112-1
