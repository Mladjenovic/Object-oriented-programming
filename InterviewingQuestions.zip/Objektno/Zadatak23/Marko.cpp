
#include <iostream>
using namespace std;

class T {
     public:
         static int t;
          T(int tt) { t += tt;}
          ~T() { --t;}
};


void printT(T t){     // posto se ovde pravi kopija nakon funkcije printT ta kopija se unistava --
    cout<<t.t;       //poziva se destruktor koji na kraju funkcije smanjuje t za 1
}

    int T::t = 1; // polje t na pocetku ima vrednost 1


int main(){
    T t(2);  // u ovoj liniji koda se pozove konstruktor i polje t dobije vrednost 3 (t += 2)
    T t2(1); // u ovoj liniji koda se pozove konstruktor i polje t dobije vrednost 4 (t += 1)
    T t3(0); // u ovoj liniji koda se pozove konstruktor i polje t dobije vrednost 4 (t += 0)

    printT(t);  // prosledjujemo parametar t po vrednosti, ispise se vrednost 4,i posle funkcije se vrednost promenljive t smanji na 3
    printT(t2); // prosledjujemo parametar t po vrednosti, ispise se vrednost 3,i posle funkcije se vrednost promenljive t smanji na 2
    printT(t3); // prosledjujemo parametar t po vrednosti, ispise se vrednost 2,i posle funkcije se vrednost promenljive t smanji na 1
    cout << t.t; // ako ovde ponovo ispisemo t, dobicemo vrednost 1
    t.t++;    cout << t.t; // sad cemo dobiti vrednost 2
    return 0;
}



