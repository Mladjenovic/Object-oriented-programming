/*
#include <iostream>
using namespace std;

int main(){

    int a=0;
    int b=4;
    int c=-5;

    int *pa;
    int *pb;
    int *pc;

    b=++a;
    c=b--;

    pa = &a;
    pb = &b;
    pc = &c;

    cout<< ++(*pa);
    cout<< (*pb)++;
    cout<< --(*pc);

    return 0;
}
*/

//Program ispisuje 200
