/*
#include <iostream>
using namespace std;

class T{

    public:
        static int t;
        T(int tt){t+=tt;}
        //~T(){--t;}

};

void printT(T t){
    cout<<t.t;
}

int T::t = 1;

int main(){

    T t(2), t2(1), t3(0);

    printT(t);
    printT(t2);
    printT(t3);

    return 0;
}
*/
//Program ispisuje 444
